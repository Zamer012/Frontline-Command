import React, { useState } from 'react';
import { UnitTypeCode } from '../types/game';
import { TacticalEngine } from '../game/engine';
import { AIR_UNITS, UNIT_BLUEPRINTS } from '../game/constants';
import { Shield, Plane, Users, Truck, Wrench, Lock, CheckCircle2 } from 'lucide-react';

interface DeploymentShopProps {
  engine: TacticalEngine;
  onSelectUnitToDeploy: (unitCode: UnitTypeCode) => void;
  selectedUnitCode: UnitTypeCode | null;
  currentGold: number;
  onOpenArmory?: () => void;
  disabled?: boolean;
}

export const DeploymentShop: React.FC<DeploymentShopProps> = ({
  engine,
  onSelectUnitToDeploy,
  selectedUnitCode,
  currentGold,
  onOpenArmory,
  disabled = false,
}) => {
  const [filter, setFilter] = useState<'all' | 'infantry' | 'armor' | 'air' | 'support'>('all');

  const unitCodes: UnitTypeCode[] = [
    'R', 'C', 'K', 'T', 'B', 'G', 'S', 'P', 'Z', 'N',
    'X', 'I', 'U', 'Q', 'V', 'M', 'A', 'D', 'Y', 'F', 'L', 'E', 'J',
  ];

  const getCategory = (code: UnitTypeCode): 'infantry' | 'armor' | 'air' | 'support' => {
    if (AIR_UNITS.includes(code) || code === 'C' || code === 'Q') return 'air';
    if ('MBALJD'.includes(code)) return 'armor';
    if ('PKNE'.includes(code)) return 'support';
    return 'infantry';
  };

  const filteredCodes = unitCodes.filter((code) => {
    if (filter === 'all') return true;
    return getCategory(code) === filter;
  });

  return (
    <div className="bg-[#141a1e] border border-[#232c32] rounded-xl p-4 flex flex-col gap-3 shadow-lg">
      <div className="flex items-center justify-between border-b border-[#232c32] pb-2.5">
        <div>
          <h3 className="text-sm font-bold text-slate-100 uppercase tracking-wider">
            Requisition Units
          </h3>
          <p className="text-[11px] text-slate-400">
            Deploy on marked grid tiles adjacent to HQ or Barracks
          </p>
        </div>
        <div className="text-right font-mono">
          <span className="text-[11px] text-slate-400 block">Field Budget</span>
          <span className="text-base font-extrabold text-amber-400 tabular-nums">
            {currentGold} <span className="text-xs font-normal text-slate-400">GOLD</span>
          </span>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1 p-1 bg-[#0e1316] rounded-lg border border-[#232c32] overflow-x-auto">
        <button
          onClick={() => setFilter('all')}
          className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
            filter === 'all'
              ? 'bg-amber-500 text-slate-950 font-bold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          All
        </button>
        <button
          onClick={() => setFilter('infantry')}
          className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap flex items-center gap-1 ${
            filter === 'infantry'
              ? 'bg-amber-500 text-slate-950 font-bold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Users className="w-3 h-3" />
          Infantry
        </button>
        <button
          onClick={() => setFilter('armor')}
          className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap flex items-center gap-1 ${
            filter === 'armor'
              ? 'bg-amber-500 text-slate-950 font-bold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Shield className="w-3 h-3" />
          Armor
        </button>
        <button
          onClick={() => setFilter('air')}
          className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap flex items-center gap-1 ${
            filter === 'air'
              ? 'bg-amber-500 text-slate-950 font-bold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Plane className="w-3 h-3" />
          Air / Recon
        </button>
        <button
          onClick={() => setFilter('support')}
          className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap flex items-center gap-1 ${
            filter === 'support'
              ? 'bg-amber-500 text-slate-950 font-bold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Wrench className="w-3 h-3" />
          Support
        </button>
      </div>

      {/* Grid of Units */}
      <div className="grid grid-cols-2 gap-2 max-h-[380px] overflow-y-auto pr-1">
        {filteredCodes.map((code) => {
          const bp = engine.getBlueprint(code);
          const maxHp = engine.getMaxHealth(code, engine.cur);
          const isSelected = selectedUnitCode === code;
          const isUnlocked = engine.isUnitUnlocked(code);
          const canAfford = currentGold >= bp.c;

          if (!isUnlocked) {
            return (
              <div
                key={code}
                onClick={onOpenArmory}
                className="p-2 rounded-lg border border-[#1b2226] bg-[#0c1012] opacity-60 flex flex-col justify-between text-left cursor-pointer hover:border-[#2d3840]"
                title="Locked: Unlock in Armory with Mits"
              >
                <div className="flex items-center justify-between gap-1 mb-1">
                  <span className="font-bold text-xs text-slate-400 truncate">{bp.n}</span>
                  <span className="text-[10px] font-mono text-amber-400/80 flex items-center gap-0.5">
                    <Lock className="w-3 h-3" /> {bp.mitsCost} M
                  </span>
                </div>
                <div className="text-[10px] font-mono text-slate-500">
                  Tap to unlock in Armory
                </div>
              </div>
            );
          }

          return (
            <button
              key={code}
              disabled={disabled || !canAfford}
              onClick={() => onSelectUnitToDeploy(code)}
              className={`p-2 rounded-lg border text-left transition-all flex flex-col justify-between ${
                isSelected
                  ? 'border-amber-400 bg-amber-500/15 shadow-md shadow-amber-900/20'
                  : 'border-[#232c32] hover:border-[#384650] bg-[#0e1316]'
              } ${!canAfford ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer'}`}
            >
              <div className="flex items-center justify-between gap-1 mb-1">
                <span className="font-bold text-xs text-slate-200 truncate">{bp.n}</span>
                <span className="font-mono font-bold text-xs text-amber-400 shrink-0">
                  {bp.c}G
                </span>
              </div>

              <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
                <span>HP {maxHp}</span>
                <span>Mv {bp.mv}</span>
                <span>{bp.ab.length} Wpn</span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
