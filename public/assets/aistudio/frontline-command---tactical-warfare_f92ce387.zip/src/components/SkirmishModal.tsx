import React, { useState } from 'react';
import { MatchConfig } from '../game/engine';
import { Swords, Users, Bot, Globe, Shield, Play } from 'lucide-react';

interface SkirmishModalProps {
  onStartMatch: (config: MatchConfig) => void;
}

export const SkirmishModal: React.FC<SkirmishModalProps> = ({ onStartMatch }) => {
  const [selectedMode, setSelectedMode] = useState<number>(0);
  const [startingGold, setStartingGold] = useState<number>(24);
  const [fogOfWar, setFogOfWar] = useState<boolean>(true);

  const modes = [
    {
      id: 0,
      title: 'Skirmish vs AI Commander',
      desc: '1v1 tactical battle against computer AI on a 15x15 sector.',
      mapSize: 15,
      players: 2,
      humans: [0],
      icon: Swords,
    },
    {
      id: 1,
      title: 'Two Players (Pass & Play)',
      desc: '1v1 local multiplayer on one device with turn cover privacy.',
      mapSize: 15,
      players: 2,
      humans: [0, 1],
      icon: Users,
    },
    {
      id: 2,
      title: 'AI vs AI Simulation',
      desc: 'Spectate two autonomous AI commanders fighting for victory.',
      mapSize: 15,
      players: 2,
      humans: [],
      icon: Bot,
    },
    {
      id: 3,
      title: 'Grand War: You vs 3 AI Powers',
      desc: 'Massive 30x30 theater with 4 corner HQs and multiple central barracks.',
      mapSize: 30,
      players: 4,
      humans: [0],
      icon: Globe,
    },
    {
      id: 4,
      title: 'Grand War: 4-Way Spectate',
      desc: 'Watch four AI factions clash in a full-scale 30x30 war.',
      mapSize: 30,
      players: 4,
      humans: [],
      icon: Bot,
    },
    {
      id: 5,
      title: 'Grand War: 4 Players Local',
      desc: '4-player hotseat conflict on one shared device.',
      mapSize: 30,
      players: 4,
      humans: [0, 1, 2, 3],
      icon: Users,
    },
  ];

  const handleLaunch = () => {
    const m = modes[selectedMode];
    onStartMatch({
      mapSize: m.mapSize,
      playersCount: m.players,
      humanFactions: m.humans,
      startingGold: Array(m.players).fill(m.mapSize > 15 ? startingGold * 2 : startingGold),
    });
  };

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-6 space-y-6">
      <div className="bg-gradient-to-r from-[#141b20] to-[#101417] border border-[#232c32] rounded-2xl p-6 chamfer-md shadow-xl">
        <div className="flex items-center gap-2 text-xs font-mono text-amber-400 mb-1">
          <Shield className="w-4 h-4" />
          <span>TACTICAL WAR ROOM SANDBOX</span>
        </div>
        <h1 className="text-2xl md:text-3xl font-extrabold text-slate-100 tracking-tight">
          Custom Skirmish Generator
        </h1>
        <p className="text-sm text-slate-400 mt-1">
          Configure a custom engagement. Earn War Bonds for victories and test new unit tactics.
        </p>
      </div>

      {/* Modes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        {modes.map((mode) => {
          const Icon = mode.icon;
          const isSelected = selectedMode === mode.id;

          return (
            <div
              key={mode.id}
              onClick={() => setSelectedMode(mode.id)}
              className={`p-4 rounded-xl border cursor-pointer transition-all ${
                isSelected
                  ? 'border-amber-400 bg-[#161e22] shadow-lg shadow-amber-950/20'
                  : 'border-[#232c32] bg-[#111619] hover:border-[#384650]'
              }`}
            >
              <div className="flex items-center gap-3 mb-2">
                <div
                  className={`w-9 h-9 rounded-lg flex items-center justify-center ${
                    isSelected ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-[#1b2328] text-slate-300'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-200 text-sm">{mode.title}</h3>
                  <span className="text-[11px] font-mono text-slate-400">
                    Grid {mode.mapSize}x{mode.mapSize} · {mode.players} Factions
                  </span>
                </div>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed pl-12">{mode.desc}</p>
            </div>
          );
        })}
      </div>

      {/* Battle Parameter Controls */}
      <div className="bg-[#12171a] p-5 rounded-xl border border-[#232c32] space-y-4">
        <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400">
          Match Parameters
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-300">Initial Deployment Treasury</span>
              <span className="text-amber-400 font-bold">{startingGold} Gold</span>
            </div>
            <input
              type="range"
              min={16}
              max={64}
              step={4}
              value={startingGold}
              onChange={(e) => setStartingGold(parseInt(e.target.value, 10))}
              className="w-full accent-amber-500 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
            />
            <div className="flex justify-between text-[10px] font-mono text-slate-500">
              <span>16 (Scarcity)</span>
              <span>64 (Blitzkrieg)</span>
            </div>
          </div>

          <div className="flex items-center justify-between p-3 bg-[#0c1012] rounded-lg border border-[#232c32]">
            <div>
              <div className="text-xs font-bold text-slate-200 font-mono">Fog of War</div>
              <div className="text-[11px] text-slate-400">Units only reveal tiles in line of sight</div>
            </div>
            <button
              onClick={() => setFogOfWar(!fogOfWar)}
              className={`px-3 py-1 text-xs font-mono font-bold rounded-lg border transition-colors ${
                fogOfWar
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}
            >
              {fogOfWar ? 'ENABLED' : 'DISABLED'}
            </button>
          </div>
        </div>

        <button
          onClick={handleLaunch}
          className="w-full py-3.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold rounded-xl text-sm flex items-center justify-center gap-2 shadow-lg shadow-amber-950/30 uppercase tracking-wider transition-all mt-4"
        >
          <Play className="w-4 h-4 fill-slate-950" />
          <span>Deploy to Sector</span>
        </button>
      </div>
    </div>
  );
};
