import React from 'react';
import { Volume2, VolumeX, Settings, Save, Shield, Star, Coins, Wrench, ShieldAlert } from 'lucide-react';

interface TopBarProps {
  currentTab: 'battle' | 'campaign' | 'armory' | 'skirmish';
  onSelectTab: (tab: 'battle' | 'campaign' | 'armory' | 'skirmish') => void;
  mits: number;
  intel: number;
  muted: boolean;
  onToggleMute: () => void;
  onOpenSettings: () => void;
  onOpenSaveManager: () => void;
  onOpenAdmin: () => void;
  isInActiveBattle: boolean;
}

export const TopBar: React.FC<TopBarProps> = ({
  currentTab,
  onSelectTab,
  mits,
  intel,
  muted,
  onToggleMute,
  onOpenSettings,
  onOpenSaveManager,
  onOpenAdmin,
  isInActiveBattle,
}) => {
  return (
    <header className="flex items-center justify-between gap-6 px-5 py-3 border-b border-[#232c32] bg-[#0c1013]/95 backdrop-blur-md sticky top-0 z-30">
      {/* Zone 1: Wordmark */}
      <div className="flex items-center gap-3 shrink-0">
        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center shadow-lg shadow-amber-900/30 border border-amber-400/40">
          <Shield className="w-4 h-4 text-slate-950 font-bold" />
        </div>
        <span className="text-base font-extrabold tracking-wider text-slate-100 uppercase whitespace-nowrap">
          Frontline Command
        </span>
      </div>

      {/* Zone 2: Navigation Links */}
      <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-400">
        <button
          onClick={() => onSelectTab('campaign')}
          className={`hover:text-slate-100 transition-colors whitespace-nowrap shrink-0 pb-0.5 ${
            currentTab === 'campaign' ? 'text-amber-400 font-semibold border-b-2 border-amber-400' : ''
          }`}
        >
          Campaign Operations
        </button>
        <button
          onClick={() => onSelectTab('armory')}
          className={`hover:text-slate-100 transition-colors whitespace-nowrap shrink-0 pb-0.5 ${
            currentTab === 'armory' ? 'text-amber-400 font-semibold border-b-2 border-amber-400' : ''
          }`}
        >
          Armory & Tech
        </button>
        <button
          onClick={() => onSelectTab('skirmish')}
          className={`hover:text-slate-100 transition-colors whitespace-nowrap shrink-0 pb-0.5 ${
            currentTab === 'skirmish' ? 'text-amber-400 font-semibold border-b-2 border-amber-400' : ''
          }`}
        >
          Custom Skirmish
        </button>
        <button
          onClick={() => onSelectTab('battle')}
          className={`hover:text-slate-100 transition-colors whitespace-nowrap shrink-0 pb-0.5 flex items-center gap-1.5 ${
            currentTab === 'battle' ? 'text-amber-400 font-semibold border-b-2 border-amber-400' : ''
          }`}
        >
          <span>Battlefield</span>
          {isInActiveBattle && (
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          )}
        </button>
      </nav>

      {/* Zone 3: Currencies & Actions */}
      <div className="flex items-center gap-3.5 shrink-0">
        {/* Mits & Intel HUD */}
        <div className="flex items-center gap-3 text-xs font-mono">
          <div className="flex items-center gap-1.5 text-amber-400 font-bold" title="Mits (Earned from Campaigns, spent in Tech Tree)">
            <Coins className="w-3.5 h-3.5 text-amber-400" />
            <span className="tabular-nums text-sm">{mits.toLocaleString()}</span>
            <span className="text-[10px] text-amber-400/80 uppercase">MITS</span>
          </div>
          <span className="text-slate-600">·</span>
          <div className="flex items-center gap-1.5 text-cyan-400 font-bold" title="Research Intel Stars">
            <Star className="w-3.5 h-3.5 fill-cyan-400/30 text-cyan-400" />
            <span className="tabular-nums text-sm">{intel}</span>
            <span className="text-[10px] text-cyan-400/80 uppercase hidden sm:inline">INTEL</span>
          </div>
        </div>

        <div className="h-4 w-px bg-slate-800 hidden sm:block" />

        {/* Admin Console Trigger */}
        <button
          onClick={onOpenAdmin}
          className="p-1.5 text-amber-400/90 hover:text-amber-300 hover:bg-amber-500/10 rounded-lg transition-colors border border-amber-500/20"
          title="Admin Panel (Protected in Campaigns, Unrestricted in Sandbox)"
        >
          <ShieldAlert className="w-4 h-4" />
        </button>

        {/* Save Manager */}
        <button
          onClick={onOpenSaveManager}
          className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800/80 rounded-lg transition-colors"
          title="Save on Device / JSON Export & Import"
        >
          <Save className="w-4 h-4" />
        </button>

        {/* Audio Mute */}
        <button
          onClick={onToggleMute}
          className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800/80 rounded-lg transition-colors"
          title={muted ? 'Unmute Audio' : 'Mute Audio'}
        >
          {muted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-slate-300" />}
        </button>

        {/* Settings */}
        <button
          onClick={onOpenSettings}
          className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800/80 rounded-lg transition-colors"
          title="Game Settings"
        >
          <Settings className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
