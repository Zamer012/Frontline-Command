import React, { useEffect, useRef } from 'react';
import { UnitInstance, Ability } from '../types/game';
import { TacticalEngine } from '../game/engine';
import { drawUnitModel } from '../game/unitRenderer';
import { FACTION_COLORS, BUILDING_DESCRIPTIONS } from '../game/constants';
import { Shield, Zap, Crosshair, Flag } from 'lucide-react';

interface UnitActionCardProps {
  unit: UnitInstance;
  engine: TacticalEngine;
  onSelectAbility: (index: number) => void;
  onToggleGroundAim: () => void;
  onCapture: (building: UnitInstance) => void;
  disabled?: boolean;
}

export const UnitActionCard: React.FC<UnitActionCardProps> = ({
  unit,
  engine,
  onSelectAbility,
  onToggleGroundAim,
  onCapture,
  disabled = false,
}) => {
  const iconCanvasRef = useRef<HTMLCanvasElement>(null);
  const bp = engine.getBlueprint(unit.t);
  const isBuilding = !!bp.bl;

  useEffect(() => {
    const canvas = iconCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.save();
    ctx.translate(canvas.width / 2, canvas.height / 2 + 5);
    const scale = 'JHOWBMAL'.includes(unit.t) ? 0.8 : 0.95;
    ctx.scale(scale, scale);
    const color = unit.o >= 0 ? FACTION_COLORS[unit.o] : '#94a3b8';
    drawUnitModel(ctx, unit.t, color, performance.now(), 0, 0);
    ctx.restore();
  }, [unit]);

  const canMove = engine.canUnitMove(unit);
  const canAct = engine.canUnitAct(unit);
  const capturableBuildings = engine.getCapturableBuildings(unit);

  const formatAbilityDesc = (a: Ability) => {
    if (a.f.includes('h')) return 'Restores 2 HP, Fuel, Ammo';
    if (a.f.includes('j')) return 'Disables target next turn';
    if (a.f.includes('r')) return `Repairs ${a.d} HP`;
    return `${a.d} Damage`;
  };

  const formatAbilityTags = (a: Ability) => {
    const tags = [
      a.f.includes('i') && 'Indirect',
      a.f.includes('d') && 'Diagonal',
      a.f.includes('s') && 'Splash Area',
      a.f.includes('a') && '+2 vs Vehicles',
      a.f.includes('b') && !a.f.includes('r') && '2x vs Structures',
      a.f.includes('u') && 'Pins Target',
      a.f.includes('x') && 'Kamikaze Suicide',
      a.cd && `${a.cd}-Turn Cooldown`,
    ].filter(Boolean);
    return tags.join(' · ');
  };

  return (
    <div className="bg-[#141a1e] border border-[#232c32] rounded-xl p-4 chamfer-sm flex flex-col gap-3 shadow-lg">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#232c32] pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-base font-bold text-slate-100">{bp.n}</h3>
            {unit.o === 0 ? (
              <span className="text-[11px] font-mono text-cyan-400">FRIENDLY</span>
            ) : unit.o > 0 ? (
              <span className="text-[11px] font-mono text-red-400">HOSTILE</span>
            ) : (
              <span className="text-[11px] font-mono text-slate-400">NEUTRAL</span>
            )}
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            {isBuilding ? 'Fortified Asset' : `${canMove ? 'Can move' : 'Moved'} · ${canAct ? 'Ready to fire' : 'Acted'}`}
          </p>
        </div>
        <canvas ref={iconCanvasRef} width={64} height={46} className="bg-[#0b0e10] rounded border border-[#232c32]" />
      </div>

      {/* Stats Meters */}
      <div className="space-y-2 text-xs font-mono">
        <div>
          <div className="flex justify-between text-slate-300 mb-1">
            <span>Hull / Health</span>
            <span className="font-semibold tabular-nums">
              {unit.hp} / {unit.maxHp}
            </span>
          </div>
          <div className="h-1.5 w-full bg-[#0b0f12] rounded-full overflow-hidden">
            <div
              className={`h-full transition-all duration-300 ${
                unit.hp / unit.maxHp > 0.5 ? 'bg-emerald-500' : unit.hp / unit.maxHp > 0.25 ? 'bg-amber-500' : 'bg-red-500'
              }`}
              style={{ width: `${Math.max(0, (unit.hp / unit.maxHp) * 100)}%` }}
            />
          </div>
        </div>

        {bp.fu != null && (
          <div>
            <div className="flex justify-between text-slate-300 mb-1">
              <span>Fuel Reserve</span>
              <span className="font-semibold tabular-nums">
                {unit.fu} / {unit.maxFu}
              </span>
            </div>
            <div className="h-1.5 w-full bg-[#0b0f12] rounded-full overflow-hidden">
              <div
                className="h-full bg-amber-500 transition-all duration-300"
                style={{ width: `${Math.max(0, ((unit.fu ?? 0) / (unit.maxFu || 1)) * 100)}%` }}
              />
            </div>
          </div>
        )}

        {bp.am != null && (
          <div>
            <div className="flex justify-between text-slate-300 mb-1">
              <span>Ammunition</span>
              <span className="font-semibold tabular-nums">
                {unit.am} / {unit.maxAm}
              </span>
            </div>
            <div className="h-1.5 w-full bg-[#0b0f12] rounded-full overflow-hidden">
              <div
                className="h-full bg-slate-400 transition-all duration-300"
                style={{ width: `${Math.max(0, ((unit.am ?? 0) / (unit.maxAm || 1)) * 100)}%` }}
              />
            </div>
          </div>
        )}
      </div>

      {/* Description for Buildings */}
      {isBuilding && (
        <div className="text-xs text-slate-400 leading-relaxed bg-[#0b0f12] p-2.5 rounded border border-[#232c32]">
          {BUILDING_DESCRIPTIONS[unit.t] || 'Military installation.'}
          {unit.t === 'W' && (
            <span className="block mt-1 text-cyan-400 font-mono">
              {unit.cd ? `Supply ready in ${unit.cd} turns` : 'Resupply ready on contact'}
            </span>
          )}
        </div>
      )}

      {/* Capture Actions */}
      {capturableBuildings.map((b) => (
        <button
          key={b.id}
          disabled={Boolean(disabled || unit.acted)}
          onClick={() => onCapture(b)}
          className="w-full py-2.5 px-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold rounded-lg text-xs flex items-center justify-center gap-2 shadow-md transition-all uppercase tracking-wider disabled:opacity-40"
        >
          <Flag className="w-4 h-4" />
          <span>Capture {engine.getBlueprint(b.t).n}</span>
        </button>
      ))}

      {/* Ground Aim Mode Toggle */}
      {!isBuilding && canMove && (
        <button
          disabled={disabled}
          onClick={onToggleGroundAim}
          className={`w-full py-2 px-3 border rounded-lg text-xs font-medium flex items-center justify-between transition-colors ${
            unit.gm
              ? 'border-amber-400/80 bg-amber-500/15 text-amber-300'
              : 'border-[#2d373e] hover:bg-[#1a2328] text-slate-300'
          }`}
        >
          <span className="flex items-center gap-1.5">
            <Crosshair className="w-3.5 h-3.5 text-amber-400" />
            <span>Target Empty Grid Tile</span>
          </span>
          <span className="font-mono text-[11px] font-bold uppercase">{unit.gm ? 'ON' : 'OFF'}</span>
        </button>
      )}

      {/* Weapons / Ability Loadout */}
      {!isBuilding && bp.ab.length > 0 && (
        <div className="space-y-1.5 mt-1">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider flex items-center justify-between">
            <span>Weapon Modes</span>
            <span>Range · Cost</span>
          </div>
          {bp.ab.map((a, i) => {
            const isSelected = (unit.ai || 0) === i;
            const canAfford = engine.canAffordAbility(unit, a);

            return (
              <button
                key={i}
                disabled={disabled || !canAfford}
                onClick={() => onSelectAbility(i)}
                className={`w-full text-left p-2.5 rounded-lg border transition-all text-xs flex flex-col gap-1 ${
                  isSelected
                    ? 'border-amber-400 bg-[#212923] text-amber-300 shadow-sm'
                    : 'border-[#232c32] hover:border-[#384650] bg-[#0e1316] text-slate-300'
                } ${!canAfford ? 'opacity-40 cursor-not-allowed' : ''}`}
              >
                <div className="flex items-center justify-between font-semibold">
                  <span className="flex items-center gap-1.5">
                    <Zap className="w-3 h-3 text-amber-400" />
                    <span>{a.n}</span>
                  </span>
                  <span className="font-mono text-[11px] text-slate-400">
                    Rng {a.rg} {a.a && a.a > 1 ? `· Ammo ${a.a}` : ''}
                  </span>
                </div>
                <div className="text-[11px] text-slate-400 flex items-center justify-between">
                  <span>{formatAbilityDesc(a)}</span>
                  {a.cd && unit.cd > 0 ? (
                    <span className="text-cyan-400 font-mono">CD: {unit.cd}</span>
                  ) : null}
                </div>
                {formatAbilityTags(a) && (
                  <div className="text-[10px] text-amber-400/80 font-mono mt-0.5">
                    {formatAbilityTags(a)}
                  </div>
                )}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
};
