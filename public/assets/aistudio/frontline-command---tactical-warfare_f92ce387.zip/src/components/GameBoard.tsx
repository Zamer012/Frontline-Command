import React, { useEffect, useRef, useState, useCallback } from 'react';
import { TacticalEngine } from '../game/engine';
import { drawUnitModel } from '../game/unitRenderer';
import { FACTION_COLORS, AIR_UNITS, NEUTRAL_COLOR, COSMETIC_SKINS } from '../game/constants';
import { ZoomIn, ZoomOut, Maximize2, Crosshair } from 'lucide-react';

interface GameBoardProps {
  engine: TacticalEngine;
  onTileClick: (x: number, y: number) => void;
  graphicsQuality: number;
}

export const GameBoard: React.FC<GameBoardProps> = ({
  engine,
  onTileClick,
  graphicsQuality,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const bgCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const [zoom, setZoom] = useState<number>(1);
  const [hoveredTile, setHoveredTile] = useState<{ x: number; y: number } | null>(null);

  // Background caching
  const renderBackground = useCallback(
    (N: number, C: number) => {
      if (!bgCanvasRef.current) {
        bgCanvasRef.current = document.createElement('canvas');
      }
      const bg = bgCanvasRef.current;
      bg.width = bg.height = N * C;
      const g = bg.getContext('2d');
      if (!g) return;

      g.textAlign = 'center';
      g.textBaseline = 'middle';

      for (let y = 0; y < N; y++) {
        for (let x = 0; x < N; x++) {
          g.fillStyle = (x + y) % 2 ? '#222926' : '#1d2320';
          g.fillRect(x * C, y * C, C, C);
          g.strokeStyle = 'rgba(212,217,211,0.06)';
          g.lineWidth = 1;
          g.strokeRect(x * C + 0.5, y * C + 0.5, C, C);

          // Obstacles
          const obVal = engine.ob[y]?.[x];
          if (obVal) {
            const cx = x * C + C / 2;
            const cy = y * C + C / 2;
            g.beginPath();
            if (obVal === 1) {
              // Rocky boulder
              g.moveTo(cx - 15, cy + 8);
              g.lineTo(cx - 9, cy - 9);
              g.lineTo(cx + 4, cy - 13);
              g.lineTo(cx + 15, cy - 2);
              g.lineTo(cx + 11, cy + 10);
              g.closePath();
              g.fillStyle = '#161a18';
              g.strokeStyle = '#4a544e';
            } else {
              // Concrete barrier ruin
              g.moveTo(cx - 20, cy + 14);
              g.lineTo(cx - 6, cy - 14);
              g.lineTo(cx + 2, cy - 2);
              g.lineTo(cx + 10, cy - 10);
              g.lineTo(cx + 21, cy + 14);
              g.closePath();
              g.fillStyle = '#121614';
              g.strokeStyle = '#5f6962';
            }
            g.fill();
            g.lineWidth = 1.5;
            g.stroke();
          }
        }
      }

      // Coordinate labels
      g.font = `${N > 15 ? 12 : 10}px JetBrains Mono, monospace`;
      g.fillStyle = 'rgba(212,217,211,0.35)';
      const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcd';
      for (let i = 0; i < N; i++) {
        g.fillText(letters[i] || `${i + 1}`, i * C + C / 2, 8);
        g.fillText(`${i + 1}`, 8, i * C + C / 2);
      }
    },
    [engine.ob]
  );

  useEffect(() => {
    renderBackground(engine.N, engine.C);
  }, [engine.N, engine.C, engine.ob, renderBackground]);

  // Main Render Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const g = canvas.getContext('2d');
    if (!g) return;

    let animId: number;

    const render = () => {
      const { N, C } = engine;
      const totalSize = N * C;

      if (canvas.width !== totalSize || canvas.height !== totalSize) {
        canvas.width = canvas.height = totalSize;
      }

      const now = performance.now();
      const vis = engine.getVisibilityMap(engine.view);

      g.clearRect(0, 0, totalSize, totalSize);
      g.save();

      // Screen Shake
      if (engine.shake > 0.4) {
        g.translate((Math.random() - 0.5) * engine.shake, (Math.random() - 0.5) * engine.shake);
        engine.shake *= 0.9;
      }

      // 1. Draw cached background
      if (bgCanvasRef.current) {
        g.drawImage(bgCanvasRef.current, 0, 0);
      }

      // 2. Scorch marks
      engine.scorch.forEach((sc) => {
        if (vis[sc.y * N + sc.x]) {
          g.globalAlpha = sc.a;
          g.fillStyle = '#080a09';
          g.beginPath();
          g.ellipse((sc.x + 0.5) * C, (sc.y + 0.5) * C + 6, sc.r, sc.r * 0.55, 0, 0, Math.PI * 2);
          g.fill();
          g.globalAlpha = 1;
        }
      });

      // 3. Tile Highlights
      const drawBox = (color: string, x: number, y: number, alpha: number, dashed = false) => {
        g.globalAlpha = alpha;
        g.fillStyle = color;
        g.fillRect(x * C + 1, y * C + 1, C - 2, C - 2);
        g.globalAlpha = Math.min(1, alpha + 0.4);
        g.strokeStyle = color;
        g.lineWidth = 1;
        if (dashed) g.setLineDash([4, 3]);
        g.strokeRect(x * C + 1.5, y * C + 1.5, C - 3, C - 3);
        g.setLineDash([]);
        g.globalAlpha = 1;
      };

      const drawBrackets = (x: number, y: number, color: string) => {
        g.strokeStyle = color;
        g.lineWidth = 2;
        g.beginPath();
        const pts = [
          [x * C + 3, y * C + 3, 1, 1],
          [(x + 1) * C - 3, y * C + 3, -1, 1],
          [x * C + 3, (y + 1) * C - 3, 1, -1],
          [(x + 1) * C - 3, (y + 1) * C - 3, -1, -1],
        ];
        for (const [px, py, sx, sy] of pts) {
          g.moveTo(px + sx * 7, py);
          g.lineTo(px, py);
          g.lineTo(px, py + sy * 7);
        }
        g.stroke();
      };

      // Movement tiles (blue)
      engine.hl.m.forEach((c) => drawBox('#38bdf8', c.x, c.y, 0.22));

      // Range tiles (red)
      engine.hl.r.forEach(([x, y]) => drawBox('#f87171', x, y, 0.15));

      // Deployment tiles (gold)
      engine.hl.s.forEach(([x, y]) => drawBox('#d3a85a', x, y, 0.3, true));

      // Attack Targets
      engine.hl.t.forEach((e) => {
        drawBox('#f87171', e.x, e.y, 0.25 + 0.12 * Math.sin(now / 180));
        drawBrackets(e.x, e.y, '#fca5a5');
      });

      // Capturable buildings
      engine.hl.c.forEach((e) => {
        drawBox('#facc15', e.x, e.y, 0.24 + 0.12 * Math.sin(now / 180));
        drawBrackets(e.x, e.y, '#facc15');
      });

      // 4. Fog of War
      if (!engine.fogOff) {
        g.fillStyle = 'rgba(7,9,11,0.76)';
        g.beginPath();
        for (let y = 0; y < N; y++) {
          for (let x = 0; x < N; x++) {
            if (!vis[y * N + x]) {
              g.rect(x * C, y * C, C, C);
            }
          }
        }
        g.fill();
      }

      // 5. Units & Structures
      const sortedUnits = [...engine.U].sort((a, b) => {
        const aAir = AIR_UNITS.includes(a.t) ? 9 : 0;
        const bAir = AIR_UNITS.includes(b.t) ? 9 : 0;
        return a.ry - b.ry + aAir - bAir;
      });

      sortedUnits.forEach((e) => {
        const bp = engine.getBlueprint(e.t);
        const isVisible = vis[Math.round(e.ry) * N + Math.round(e.rx)] || e.o === engine.view;

        // Enemy units inside fog are hidden (unless neutral building)
        if (!isVisible && !(bp.bl && e.t !== 'H')) return;

        const isAir = AIR_UNITS.includes(e.t);
        const isFriendly = e.o === engine.view;
        const isDamagedFlash = now - (e.fl || 0) < 250;
        const X = (e.rx + 0.5) * C + e.wx + (isDamagedFlash ? (Math.random() - 0.5) * 5 : 0);
        const Y = (e.ry + 0.5) * C;
        let factionColor = isVisible && e.o >= 0 ? FACTION_COLORS[e.o] : NEUTRAL_COLOR;
        if (isVisible && e.o === 0 && engine.profile?.activeSkin) {
          const equippedSkin = COSMETIC_SKINS.find((s) => s.id === engine.profile?.activeSkin);
          if (equippedSkin && equippedSkin.accentColor) {
            factionColor = equippedSkin.accentColor;
          }
        }
        const isDone =
          e.o === engine.cur &&
          isFriendly &&
          !bp.bl &&
          !engine.canUnitMove(e) &&
          !engine.canUnitAct(e) &&
          !engine.getCapturableBuildings(e).length;

        const ly = Y - (isAir ? 10 : 0) - 2;
        e.rc *= 0.9;

        // Ground shadow
        g.globalAlpha = isVisible ? 1 : 0.45;
        g.fillStyle = 'rgba(0,0,0,0.45)';
        g.beginPath();
        g.ellipse(X + (isAir ? 8 : 0), Y + 16 + (isAir ? 8 : 0), bp.bl ? 26 : isAir ? 13 : 19, isAir ? 4 : 6, 0, 0, Math.PI * 2);
        g.fill();

        // Tactical selection ring
        g.strokeStyle = factionColor;
        g.lineWidth = isFriendly ? 2.5 : 1.5;
        g.setLineDash(isFriendly || e.o < 0 ? [] : [5, 3]);
        g.beginPath();
        g.ellipse(X, Y + 15, bp.bl ? 27 : 21, bp.bl ? 9 : 7, 0, 0, Math.PI * 2);
        g.stroke();
        g.setLineDash([]);

        if (e === engine.sel) {
          const z = Math.sin(now / 150);
          g.globalAlpha = 0.6 + 0.3 * z;
          g.strokeStyle = '#facc15';
          g.lineWidth = 2.5;
          g.beginPath();
          g.ellipse(X, Y + 15, (bp.bl ? 32 : 26) + z * 2, (bp.bl ? 12 : 10) + z, 0, 0, Math.PI * 2);
          g.stroke();
        }

        // Draw Unit Model
        g.save();
        g.translate(X, ly);
        const scaleFactor = e.t === 'H' ? 1.15 : 1;
        g.scale((bp.bl ? 1 : e.dr) * scaleFactor, scaleFactor);
        g.globalAlpha = (isDone ? 0.55 : 1) * (isVisible ? 1 : 0.45);
        drawUnitModel(g, e.t, factionColor, now + e.ph, e.mw, e.rc);
        g.restore();

        // Flash on damage
        if (isDamagedFlash) {
          g.globalAlpha = 0.7 * (1 - (now - (e.fl || 0)) / 250);
          g.fillStyle = '#fff';
          g.beginPath();
          g.ellipse(X, ly, 19, 17, 0, 0, Math.PI * 2);
          g.fill();
        }

        // Frozen / EMP effect
        if (e.fz) {
          g.globalAlpha = 0.8;
          g.strokeStyle = '#7fc4d6';
          g.lineWidth = 1.5;
          for (let i = 0; i < 2; i++) {
            g.beginPath();
            g.moveTo(X - 16, ly - 12 + Math.random() * 24);
            g.lineTo(X + 16, ly - 12 + Math.random() * 24);
            g.stroke();
          }
          g.fillStyle = 'rgba(127,196,214,0.25)';
          g.beginPath();
          g.ellipse(X, ly, 20, 18, 0, 0, Math.PI * 2);
          g.fill();
        }

        // Health bar & badges
        g.globalAlpha = 1;
        if (isVisible) {
          const hpRatio = e.hp / e.maxHp;
          const by = Y + 21;
          g.fillStyle = '#0b0e0f';
          g.fillRect(X - 18, by, 36, 4);
          g.fillStyle = hpRatio > 0.5 ? '#22c55e' : hpRatio > 0.25 ? '#eab308' : '#ef4444';
          g.fillRect(X - 18, by, 36 * Math.max(0, hpRatio), 4);

          g.font = '700 10px JetBrains Mono, monospace';
          if (e.cd > 0 && e.o >= 0) {
            g.fillStyle = '#38bdf8';
            g.fillText(`CD${e.cd}`, X + 20, Y - 20);
          }
          if (e.am === 0 || e.fu === 0) {
            g.fillStyle = '#f59e0b';
            g.fillText('!', X - 20, Y - 20);
          }
        }
      });

      // 6. Projectiles and FX
      engine.fx.forEach((f) => {
        if (f.f === 'r') {
          // Shockwave ring
          if (vis[f.y * N + f.x]) {
            g.globalAlpha = 1 - f.k;
            g.strokeStyle = f.c;
            g.lineWidth = 3.5;
            g.beginPath();
            g.arc((f.x + 0.5) * C, (f.y + 0.5) * C, f.k * (f.R || 70), 0, Math.PI * 2);
            g.stroke();
            g.globalAlpha = 1;
          }
        } else if (f.f === 't') {
          // Floating Text
          g.fillStyle = f.c;
          g.font = '700 20px JetBrains Mono, monospace';
          g.textAlign = 'center';
          g.fillText(f.s || '', (f.x + 0.5) * C, (f.y + 0.2) * C - f.k * 32);
        } else if (f.seen) {
          const X = (f.x + 0.5) * C;
          const Y = (f.y + 0.5) * C;
          if (f.f === 'p') {
            g.strokeStyle = g.fillStyle = f.c;
            if (f.l) {
              g.lineWidth = 3;
              g.beginPath();
              g.moveTo(((f.ox || 0) + 0.5) * C, ((f.oy || 0) + 0.5) * C);
              g.lineTo(X, Y);
              g.stroke();
            } else {
              g.beginPath();
              g.arc(X, Y - (f.h || 0), f.r || 3, 0, Math.PI * 2);
              g.fill();
            }
          } else if (f.big) {
            const k = f.k;
            const R = (0.3 + 0.7 * Math.sqrt(k)) * 92;
            const a = 1 - k;
            const gr = g.createRadialGradient(X, Y, 0, X, Y, R);
            gr.addColorStop(0, `rgba(255,255,235,${a})`);
            gr.addColorStop(0.3, `rgba(255,205,90,${0.95 * a})`);
            gr.addColorStop(0.7, `rgba(240,100,30,${0.6 * a})`);
            gr.addColorStop(1, 'rgba(110,30,10,0)');
            g.fillStyle = gr;
            g.beginPath();
            g.arc(X, Y, R, 0, Math.PI * 2);
            g.fill();
          } else {
            g.globalAlpha = 1 - f.k;
            g.fillStyle = f.c;
            g.beginPath();
            g.arc(X, Y, f.k * (f.b ? 46 : 26), 0, Math.PI * 2);
            g.fill();
            g.globalAlpha = 1;
          }
        }
      });

      // 7. Particles
      if (engine.pt.length > 300) engine.pt.splice(0, engine.pt.length - 300);
      engine.pt = engine.pt.filter((p) => p.l > 0);
      engine.pt.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;
        p.vx *= 0.96;
        p.vy = p.vy * 0.96 + (p.gv || 0);
        p.l -= p.d;
        if (vis[p.gy * N + p.gx]) {
          g.globalAlpha = Math.max(0, p.l);
          g.fillStyle = p.c;
          g.beginPath();
          g.arc(p.x, p.y, p.s * p.l + 0.5, 0, Math.PI * 2);
          g.fill();
        }
      });
      g.globalAlpha = 1;

      // 8. Screen Flash
      if (engine.flash > 0.02) {
        g.fillStyle = `rgba(255,236,190,${engine.flash * 0.4})`;
        g.fillRect(0, 0, totalSize, totalSize);
        engine.flash *= 0.85;
      }

      g.restore();
      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [engine, graphicsQuality]);

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const clientX = e.clientX - rect.left;
    const clientY = e.clientY - rect.top;

    const tileX = Math.floor((clientX / rect.width) * engine.N);
    const tileY = Math.floor((clientY / rect.height) * engine.N);

    if (engine.inBounds(tileX, tileY)) {
      onTileClick(tileX, tileY);
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const tileX = Math.floor(((e.clientX - rect.left) / rect.width) * engine.N);
    const tileY = Math.floor(((e.clientY - rect.top) / rect.height) * engine.N);
    if (engine.inBounds(tileX, tileY)) {
      setHoveredTile({ x: tileX, y: tileY });
    } else {
      setHoveredTile(null);
    }
  };

  return (
    <div
      ref={containerRef}
      className="relative flex flex-col items-center justify-center p-2 rounded-xl bg-[#0f1418] border border-[#232c32] shadow-2xl overflow-hidden max-w-full"
    >
      {/* Top Overlay Controls */}
      <div className="absolute top-3 right-3 z-10 flex items-center gap-1.5 p-1 bg-[#161c20]/90 backdrop-blur-md rounded-lg border border-[#2d373e]">
        <button
          onClick={() => setZoom((z) => Math.max(0.7, +(z - 0.15).toFixed(2)))}
          className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded transition-colors"
          title="Zoom Out"
        >
          <ZoomOut className="w-4 h-4" />
        </button>
        <span className="text-xs font-mono text-slate-400 px-1">{Math.round(zoom * 100)}%</span>
        <button
          onClick={() => setZoom((z) => Math.min(1.6, +(z + 0.15).toFixed(2)))}
          className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded transition-colors"
          title="Zoom In"
        >
          <ZoomIn className="w-4 h-4" />
        </button>
        <button
          onClick={() => setZoom(1)}
          className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded transition-colors"
          title="Reset View"
        >
          <Maximize2 className="w-4 h-4" />
        </button>
      </div>

      {/* Hover Coordinate HUD */}
      {hoveredTile && (
        <div className="absolute top-3 left-3 z-10 flex items-center gap-2 px-2.5 py-1 bg-[#161c20]/90 backdrop-blur-md rounded-lg border border-[#2d373e] text-xs font-mono text-slate-300">
          <Crosshair className="w-3.5 h-3.5 text-amber-400" />
          <span>
            GRID: {'ABCDEFGHIJKLMNOPQRSTUVWXYZ'[hoveredTile.x] || hoveredTile.x + 1}
            {hoveredTile.y + 1} ({hoveredTile.x},{hoveredTile.y})
          </span>
        </div>
      )}

      {/* Main Canvas with touch and zoom support */}
      <div
        className="w-full flex items-center justify-center overflow-auto max-h-[78vh] p-2"
        style={{ transform: `scale(${zoom})`, transformOrigin: 'center center', transition: 'transform 120ms ease-out' }}
      >
        <canvas
          ref={canvasRef}
          onClick={handleCanvasClick}
          onMouseMove={handleMouseMove}
          onMouseLeave={() => setHoveredTile(null)}
          className="rounded-lg shadow-inner cursor-crosshair border border-[#2c373e]"
          style={{
            maxWidth: engine.N > 15 ? '920px' : '680px',
            width: '100%',
            aspectRatio: '1/1',
          }}
        />
      </div>
    </div>
  );
};
